﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBO_Projek.Controller
{
    public class C_Login_Register
    {
        C_MainFrame Controller;
        public C_Login_Register(C_MainFrame controller) 
        {
            Controller = controller;
        }
        
    }
}
